 import React from 'react'
 
 function Panels  (props){
     return( 
         <div>Panels</div>
     )
 }
 
 export default Panels 