 import React from 'react'
 
 function SideBar  (props){
     return( 
         <div>SideBar</div>
     )
 }
 
 export default SideBar 