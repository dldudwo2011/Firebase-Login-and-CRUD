 import React from 'react'
 
 function AppBar  (props){
     return( 
         <nav>
             appbar
         </nav>
     )
 }
 
 export default AppBar 
 