  import React from 'react'
import { Panels } from '../components/panels'
import { SideBar } from '../components/sidebar'
  
  import {AppBar} from './../components/appbar'

  function DashBoardPage  (props){
      return( 
          <>
          <AppBar/>
          <SideBar/>
          <Panels/>
          </>
      )
  }
  
  export default DashBoardPage 