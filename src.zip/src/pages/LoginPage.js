 import React from 'react'
 
 function LoginPage  (props){
     return( 
        <header>
            <h1>Login Page</h1>
        </header>
     )
 }
 
 export default LoginPage 