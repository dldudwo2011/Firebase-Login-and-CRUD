import DashBoardPage from "./pages/DashBoardPage";
import LoginPage from "./pages/LoginPage";

 
function App() {
 
  return (
        <>
         <DashBoardPage/>
      
        </>
  );
}

export default App;

 
 